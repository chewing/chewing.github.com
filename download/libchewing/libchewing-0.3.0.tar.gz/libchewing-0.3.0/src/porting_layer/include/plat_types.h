#ifndef __PLAT_TYPES_H__
#define __PLAT_TYPES_H__

#include "sys/plat_posix.h"
#include "sys/plat_win32.h"

#endif /* __PLAT_TYPES_H__ */

