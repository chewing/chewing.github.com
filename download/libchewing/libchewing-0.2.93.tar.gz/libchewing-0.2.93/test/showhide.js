function show_div(div_id) {
    document.getElementById(div_id).style.display = 'block';
}
function hide_div(div_id) {
    document.getElementById(div_id).style.display = 'none';
}
